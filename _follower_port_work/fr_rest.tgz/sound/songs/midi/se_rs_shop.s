	.include "MPlayDef.s"

	.equ	se_rs_shop_grp, voicegroup127
	.equ	se_rs_shop_pri, 5
	.equ	se_rs_shop_rev, reverb_set+50
	.equ	se_rs_shop_mvl, 90
	.equ	se_rs_shop_key, 0
	.equ	se_rs_shop_tbs, 1
	.equ	se_rs_shop_exg, 1
	.equ	se_rs_shop_cmp, 1

	.section .rodata
	.global	se_rs_shop
	.align	2

@**************** Track 1 (Midi-Chn.1) ****************@

se_rs_shop_1:
	.byte	KEYSH , se_rs_shop_key+0
@ 000   ----------------------------------------
	.byte	TEMPO , 128*se_rs_shop_tbs/2
	.byte		VOICE , 6
	.byte		BENDR , 12
	.byte		VOL   , 127*se_rs_shop_mvl/mxv
	.byte		BEND  , c_v-1
	.byte		N01   , Ds3 , v127
	.byte	W02
	.byte		N03   , Gs3 , v100
	.byte	W05
	.byte		N16   , Fn5 , v072
	.byte	W05
@ 001   ----------------------------------------
	.byte	W12
@ 002   ----------------------------------------
	.byte	FINE

@**************** Track 2 (Midi-Chn.2) ****************@

se_rs_shop_2:
	.byte	KEYSH , se_rs_shop_key+0
@ 000   ----------------------------------------
	.byte		VOICE , 14
	.byte		VOL   , 127*se_rs_shop_mvl/mxv
	.byte		BEND  , c_v-8
	.byte	W02
	.byte		N03   , Gs3 , v060
	.byte	W05
	.byte		N16   , Fn5 
	.byte	W05
@ 001   ----------------------------------------
	.byte	W12
@ 002   ----------------------------------------
	.byte	FINE

@******************************************************@
	.align	2

se_rs_shop:
	.byte	2	@ NumTrks
	.byte	0	@ NumBlks
	.byte	se_rs_shop_pri	@ Priority
	.byte	se_rs_shop_rev	@ Reverb.

	.word	se_rs_shop_grp

	.word	se_rs_shop_1
	.word	se_rs_shop_2

	.end
